#!/bin/sh
##################
# Environment
##################
SPLUNK_HOME=`ps -fe | grep -i splunkd | grep kvstore | awk '{print $8}' | sed -e 's/\/bin\/splunkd//g'`
SCRIPT_HOME="$SPLUNK_HOME"
TIME_OFFSET_AGO_START="10"
TIME_OFFSET_AGO_END="5"
QUERY_CONV_ID_TEMPLATE="$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/query_json_conversation_detail_list_template.json"
QUERY_CONV_ID="$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/query_json_conversation_detail_list.json"
ENV_TIMESTAMP_LABLE="N"
ENV_SINGLE_JSON_LINE="Y"
LOOPQUERY="Y"

##################
# ARGV Parsing
##################
for i in "$@"; do
  case $i in
    -t=*|--timewindow=*)
      USER_DEFINED_TIME_WINDOW="${i#*=}"
      shift # past argument=value
      ;;
    -l=*|--loopquery=*)
      LOOPQUERY="${i#*=}"
      shift # past argument=value
      ;;
    *)
      # unknown option
      ;;
  esac
done


#USER_DEFINED_TIME_WINDOW=$1

if [ "$#" -eq  "0" ] ; then
	TIME_OFFSET_AGO_END="5"
	TIME_OFFSET_AGO_START="10"
else
	if [ $USER_DEFINED_TIME_WINDOW -gt "0" ] ; then
		TIME_OFFSET_AGO_END="0"
		TIME_OFFSET_AGO_START="`expr $TIME_OFFSET_AGO_END + $USER_DEFINED_TIME_WINDOW`"
	else
		TIME_OFFSET_AGO_END="5"
		TIME_OFFSET_AGO_START="10"
	fi
fi

#------------------> Process Time Stamps
#"interval": "2021-11-28T05:00:00.000Z/2021-11-30T05:00:00.000Z",

TIME_YR_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%Y`
TIME_MON_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%m`
TIME_DAY_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%d`
TIME_HR_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%H`
TIME_MINUTE_P5_TEN=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%M | sed -e 's/[0-9]$//'`
TIME_MINUTE_P5_ONE=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%M | sed -e 's/^[0-9]//'`

TIME_YR_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%Y`
TIME_MON_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%m`
TIME_DAY_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%d`
TIME_HR_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%H`
TIME_MINUTE_CUR_TEN=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%M | sed -e 's/[0-9]$//'`
TIME_MINUTE_CUR_ONE=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%M | sed -e 's/^[0-9]//'`

if [ $TIME_MINUTE_CUR_ONE -gt 5 ] ; then
	TIME_MINUTE_CUR_ONE=5
else
	TIME_MINUTE_CUR_ONE=0
fi

if [ $TIME_MINUTE_P5_ONE -gt 5 ] ; then
        TIME_MINUTE_P5_ONE=5
else
        TIME_MINUTE_P5_ONE=0
fi

TIME_MINUTE_P5_COMB="$TIME_MINUTE_P5_TEN$TIME_MINUTE_P5_ONE"
TIME_MINUTE_CUR_COMB="$TIME_MINUTE_CUR_TEN$TIME_MINUTE_CUR_ONE"

TIME_START="$TIME_YR_P5-$TIME_MON_P5-${TIME_DAY_P5}T${TIME_HR_P5}:${TIME_MINUTE_P5_COMB}:00"
TIME_END="$TIME_YR_CUR-$TIME_MON_CUR-${TIME_DAY_CUR}T${TIME_HR_CUR}:${TIME_MINUTE_CUR_COMB}:00"

################################################
##------------------> Create JSON Query
################################################
#QUERY_CONV_ID_TEMPLATE="$SCRIPT_HOME/query_json_conversation_detail_list_template.json"
#QUERY_CONV_ID="$SCRIPT_HOME/query_json_conversation_detail_list.json"

#cat $QUERY_CONV_ID_TEMPLATE | sed -e "s/__START_TIME__/$TIME_START/g" -e "s/__END_TIME__/$TIME_END/g" > $QUERY_CONV_ID

################################################
#------------------> Fetch Converation Lists
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation list dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi

### CLEAN FILE
cat /dev/null > /tmp/splunk_genesys_cloud_conv_id_list

for each_page in 1 2 3 4 5
do
	cat $QUERY_CONV_ID_TEMPLATE | sed -e "s/__START_TIME__/$TIME_START/g" -e "s/__END_TIME__/$TIME_END/g" -e "s/__PAGE_NUMBER__/$each_page/g" > $QUERY_CONV_ID
	$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc analytics conversations details query create --file $QUERY_CONV_ID >> /tmp/splunk_genesys_cloud_conv_id_list
done

#CONV_ID_LIST="`cat  /tmp/splunk_genesys_cloud_conv_id_list | grep -i conversationid | awk -F":" '{print $2}' | sed -e 's/"//g' -e 's/,//g' -e 's/ //g' | tr '\n' ' ' | sed -e 's/,/ /g' | tee /tmp/splunk_genesys_cloud_conv_id_list_id_only`"
CONV_ID_LIST="`cat  /tmp/splunk_genesys_cloud_conv_id_list | grep -i conversationid | awk -F":" '{print $2}' | sed -e 's/"//g' -e 's/,//g' -e 's/ //g' | sed -e 's/,/ /g' | tee /tmp/splunk_genesys_cloud_conv_id_list_id_only`"
CONV_ID_COUNT="`date +%Y-%m-%d-%H:%M:%S` : Total event count `cat  /tmp/splunk_genesys_cloud_conv_id_list_id_only | wc -l`"
#echo "$CONV_ID_COUNT : Starting time `date`" >> /tmp/gc_conv_detail_loop_record_count.log

	if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
		cat /tmp/splunk_genesys_cloud_conv_id_list | egrep -v '^{|^  \"conversations\": \[|^}|^  \"totalHits\"|^  \],' |\
			sed -e 's/^    }/    } EOL/g' | tr '\n' ' ' |\
			sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g'  -e 's/} /}/g' -e 's/^{\"conversations\": \[//g' -e 's/\], \"totalHits\": 1}//g' |\
			sed -e 's/{ \"conversationEnd/\n{ \"conversationEnd/g' -e 's/EOL/\n/g' -e 's/^[ ]*//g' |\
			sed -e 's/^, *//g'
		echo ""
	else
		cat /tmp/splunk_genesys_cloud_conv_id_list
	fi

################################################
#------------------> Fetch Converation Details
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation detail dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi

#gc analytics conversations details list --id $CONV_ID_LIST

if [ $LOOPQUERY = "Y" ] ; then
	#for CONV_ID in $CONV_ID_LIST
	for CONV_ID in $(cat /tmp/splunk_genesys_cloud_conv_id_list_id_only )
	do
        	if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
			$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc conversations get $CONV_ID | tr '\n' ' ' | sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g' -e 's/} /}/g'
			#echo "processed id `date +%H:%M:%S` ID : $CONV_ID " >> /tmp/gc_conv_detail_loop_record_count.log
			echo ""
		else
			$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc conversations get $CONV_ID
		fi
	done
else
	dummy=1
fi

echo "$CONV_ID_COUNT : completed_time `date +%H:%M:%S` : start $TIME_START : end $TIME_END" >> /tmp/gc_conv_detail_loop_record_count.log

exit

