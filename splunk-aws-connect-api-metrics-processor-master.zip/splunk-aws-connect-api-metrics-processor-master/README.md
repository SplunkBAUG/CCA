# splunk-aws-connect-api-metrics-processor
Get Amazon Connect real-time and historic metric data from Connect REST endpoints
