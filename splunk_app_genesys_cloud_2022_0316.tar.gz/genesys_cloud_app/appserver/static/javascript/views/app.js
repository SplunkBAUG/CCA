import * as Setup from "./setup_page.js";
import * as Config from './setup_configuration.js'

define(["react", "splunkjs/splunk"], function(react, splunk_js_sdk){
  const e = react.createElement;

  class SetupPage extends react.Component {
    constructor(props) {
      super(props);

      this.state = { };

      Config.create_splunk_js_sdk_service(splunk_js_sdk,'genesys_cloud_app').get('properties/macros/genesys_cloud_index/definition').then((definition) => {
        this.setState({ ...this.state, genesys_cloud_index: definition})
      });

      Config.create_splunk_js_sdk_service(splunk_js_sdk,'genesys_cloud_app').get('properties/macros/genesys_cloud_correlation_index/definition').then((definition) => {
        this.setState({ ...this.state, genesys_cloud_correlation_index: definition})
      });

      this.handleChange = this.handleChange.bind(this);
      this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
      this.setState({ [event.target.name]: event.target.value})
    }

    async handleSubmit(event) {
      event.preventDefault();
      if (!this.state.genesys_cloud_index || !this.state.genesys_cloud_correlation_index) {
        alert("The query field cannot be empty. Enter a valid query to continue configuration.");
      } else if (this.state.genesys_cloud_index === "index=<define your index> sourcetype=cas_siem_consumer"){
        alert("The default index value is not changed in the query. Enter an index value to search the events.");
      } else {
        await Setup.perform(splunk_js_sdk, this.state)
      }
    }

    render() {
      return e("div", null, [
        e("h2", { className: "genesys_cloud-h2"}, "Citrix Analytics App for Splunk configuration"),
        e("div", null, [
          e("p", { className: "genesys_cloud-primaryMessage" }, " To configure the \"Citrix Analytics App for Splunk\" app please provide the following two basic searches."),
          e("form", { className: "genesys_cloud-form", onSubmit: this.handleSubmit }, [
            e("label", { className: "genesys_cloud-input_label"}, [
              "Enter query to search Citrix Analytics events:",
              e("br"),
              e("input", { className:"genesys_cloud-input_textbox", type: "text", name: "genesys_cloud_index", value: this.state.genesys_cloud_index, onChange: this.handleChange })
            ]),
            e("label", { className: "genesys_cloud-input_label"}, [
              "Enter query to search events to correlate with Citrix Analytics events: ",
              e("br"),
              e("input", { className:"genesys_cloud-input_textbox", type: "text", name: "genesys_cloud_correlation_index", value: this.state.genesys_cloud_correlation_index, onChange: this.handleChange })
            ]),
            e("div", { className: "genesys_cloud-dialog-tray"}, [
              e("input", { className: "genesys_cloud-submit", type: "submit", value: "Finish App Setup" })
            ])
          ])
        ])
      ]);
    }
  }

  return e(SetupPage);
});
