This is an add-on powered by the Splunk Add-on Builder.
# Binary File Declaration
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/pvectorc.cpython-37m-x86_64-linux-gnu.so: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/markupsafe/_speedups.cpython-37m-x86_64-linux-gnu.so: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/setuptools/cli-32.exe: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/setuptools/cli-64.exe: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/setuptools/gui.exe: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/setuptools/gui-32.exe: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/setuptools/cli.exe: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py3/setuptools/gui-64.exe: this file does not require any source code
/opt/splunk_cca_dev/var/data/tabuilder/package/TA_genesys_cloud/bin/ta_genesys_cloud/aob_py2/markupsafe/_speedups.so: this file does not require any source code
