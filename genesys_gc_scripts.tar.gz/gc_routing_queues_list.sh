#!/bin/sh
##################
# Environment
##################
SPLUNK_HOME=`ps -fe | grep -i splunkd | grep kvstore | awk '{print $8}' | sed -e 's/\/bin\/splunkd//g'`
SCRIPT_HOME="$SPLUNK_HOME"
ENV_TIMESTAMP_LABLE="N"
ENV_SINGLE_JSON_LINE="Y"

################################################
#------------------> Queue Lists
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation detail dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi


if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
	$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc routing queues list -a | egrep -v '^\]|^\[' | sed -e 's/^    \"id/NEW_REC \"id/g' | tr '\n' ' ' | sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g'  -e 's/} /}/g' | sed -e 's/{NEW_REC */\n{/g' | sed -e 's/, *$//g' -e 's/^ *//'
	echo ""
else
	$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc routing queues list -a
fi

