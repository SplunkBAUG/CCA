#!/bin/sh
##################
# Environment
##################
SPLUNK_HOME=`ps -fe | grep -i splunkd | grep kvstore | awk '{print $8}' | sed -e 's/\/bin\/splunkd//g'`
SCRIPT_HOME="$SPLUNK_HOME"
TIME_OFFSET_AGO_START="35"
TIME_OFFSET_AGO_END="5"
QUERY_CONV_ID_TEMPLATE="$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/query_json_conversation_detail_list_template.json"
QUERY_CONV_ID="$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/query_json_conversation_detail_list.json"
ENV_TIMESTAMP_LABLE="N"
ENV_SINGLE_JSON_LINE="Y"

#------------------> Process Time Stamps
#"interval": "2021-11-28T05:00:00.000Z/2021-11-30T05:00:00.000Z",

TIME_MINUTE_CUR_TEN=`date +%M | sed -e 's/[0-9]$//'`
TIME_MINUTE_CUR_ONE=`date +%M | sed -e 's/^[0-9]//'`
if [ $TIME_MINUTE_CUR_ONE -gt 5 ] ; then
	TIME_MINUTE_CUR_ONE=5
else
	TIME_MINUTE_CUR_ONE=0
fi

TIME_MINUTE_CUR_COMB="$TIME_MINUTE_CUR_TEN$TIME_MINUTE_CUR_ONE"

TIME_YR_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%Y`
TIME_MON_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%m`
TIME_DAY_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%d`
TIME_HR_P5=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%H`
TIME_MINUTE_P5_TEN=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%M | sed -e 's/[0-9]$//'`
TIME_MINUTE_P5_ONE=`date --date="${TIME_OFFSET_AGO_START} minutes ago" +%M | sed -e 's/^[0-9]//'`

TIME_YR_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%Y`
TIME_MON_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%m`
TIME_DAY_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%d`
TIME_HR_CUR=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%H`
TIME_MINUTE_CUR_TEN=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%M | sed -e 's/[0-9]$//'`
TIME_MINUTE_CUR_ONE=`date --date="${TIME_OFFSET_AGO_END} minutes ago" +%M | sed -e 's/^[0-9]//'`

if [ $TIME_MINUTE_P5_ONE -gt 5 ] ; then
        TIME_MINUTE_P5_ONE=5
else
        TIME_MINUTE_P5_ONE=0
fi

TIME_MINUTE_P5_COMB="$TIME_MINUTE_P5_TEN$TIME_MINUTE_P5_ONE"

TIME_START="$TIME_YR_P5-$TIME_MON_P5-${TIME_DAY_P5}T${TIME_HR_P5}:${TIME_MINUTE_P5_COMB}:00"
TIME_END="$TIME_YR_CUR-$TIME_MON_CUR-${TIME_DAY_CUR}T${TIME_HR_CUR}:${TIME_MINUTE_CUR_COMB}:00"

#------------------> Create JSON Query
QUERY_CONV_ID_TEMPLATE="$SCRIPT_HOME/query_json_conversation_detail_list_template.json"
QUERY_CONV_ID="$SCRIPT_HOME/query_json_conversation_detail_list.json"

cat $QUERY_CONV_ID_TEMPLATE | sed -e "s/__START_TIME__/$TIME_START/g" -e "s/__END_TIME__/$TIME_END/g" > $QUERY_CONV_ID

#------------------> Fetch Converation Lists
echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation list dump data timestamp : Between $TIME_START -> $TIME_END"
#gc analytics conversations details query create --file $QUERY_CONV_ID | tee /tmp/splunk_genesys_cloud_conv_id_list
#gc users list | grep "^      \"id" | sed -e "s/\"//g" -e "s/\,//g" -e "s/ //g" | awk -F":" '{print $2}'

USER_LIST="`$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc users list | grep '^      \"id' | sed -e 's/\"//g' -e 's/\,//g' -e 's/ //g' | awk -F':' '{print $2}' | tr '\n' ' '`"

#------------------> Fetch Converation Details
echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation detail dump data timestamp : Between $TIME_START -> $TIME_END"
#gc analytics conversations details list --id $CONV_ID_LIST

for USER_ID in $USER_LIST
do
	$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc users state get $USER_ID | sed -e "s/{/{\n  \"user_id\": \"$USER_ID\"\,/g"
done

