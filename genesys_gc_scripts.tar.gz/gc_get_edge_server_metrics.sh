#!/bin/sh
##################
# Environment
##################
SPLUNK_HOME=`ps -fe | grep -i splunkd | grep kvstore | awk '{print $8}' | sed -e 's/\/bin\/splunkd//g'`
SCRIPT_HOME="$SPLUNK_HOME"
ENV_TIMESTAMP_LABLE="N"
ENV_SINGLE_JSON_LINE="Y"

################################################
#------------------> Fetch Edge Lists
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation list dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi

$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc telephony providers edges list > /tmp/splunk_genesys_cloud_edge_node_list

ENTITY_LIST="`cat /tmp/splunk_genesys_cloud_edge_node_list | grep \"^      \\"id\" | awk -F\":\" '{print $2}' | sed -e 's/"//g' -e 's/,//g'  -e 's/ //g' | tr '\n' ',' | sed -e 's/,$//g' `"

if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
	cat /tmp/splunk_genesys_cloud_edge_node_list | egrep -v '^\]|^\[' | sed -e 's/^    \"id/NEW_REC \"id/g' | tr '\n' ' ' | sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g'  -e 's/} /}/g' | sed -e 's/{NEW_REC */\n{/g' | sed -e 's/, *$//g'
	echo ""
else
	cat /tmp/splunk_genesys_cloud_edge_node_list
fi

################################################
#------------------> Fetch Converation Details
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation detail dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi


if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
	$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc telephony providers edges metrics list --edgeIds $ENTITY_LIST | egrep -v '^\]|^\[' | sed -e 's/^    \"edge/NEW_REC \"edge/g' | tr '\n' ' ' | sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g'  -e 's/} /}/g' | sed -e 's/{NEW_REC */\n{/g' | sed -e 's/, *$//g' -e 's/^ *//'
	echo ""
else
	$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc telephony providers edges metrics list --edgeIds $ENTITY_LIST
fi

exit 

#!/bin/sh

APP_DIRECTORY="/opt/splunk_cca_dev/etc/apps/TA_genesys_cloud/bin/genesys_api_shell"
OUT_DIRECTORY="/opt/data/genesys_api"

LIST_EDGES_CONF="$APP_DIRECTORY/list_edges.conf"
LIST_EDGES="`cat $LIST_EDGES_CONF`"
RESULT_OUTPUT_FILE="$OUT_DIRECTORY/gc_telephony_providers_edges_metrics.log"

for each_edge in $LIST_EDGES
do
	/usr/local/bin/gc telephony providers edges metrics list --edgeIds $each_edge | tr '\n' ' ' | sed 's/\s\+/ /g' | tee $RESULT_OUTPUT_FILE
done
