#!/bin/sh
##################
# Environment
##################
SPLUNK_HOME=`ps -fe | grep -i splunkd | grep kvstore | awk '{print $8}' | sed -e 's/\/bin\/splunkd//g'`
SCRIPT_HOME="$SPLUNK_HOME"
ENV_TIMESTAMP_LABLE="N"
ENV_SINGLE_JSON_LINE="Y"

################################################
#------------------> Fetch Edge Lists
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation list dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi

$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc telephony providers edges trunks list --autopaginate > /tmp/splunk_genesys_cloud_edge_trunks_list

#ENTITY_LIST="`cat /tmp/splunk_genesys_cloud_edge_trunks_list | grep -i \\\/edges\\\/trunks\\\/ | sed -e 's/\"//g' | awk -F\"/trunks/\" '{print $2}' | tr '\n' ' ' | sed -e 's/ /,/g' | sed -e 's/, *$//g'`"
ENTITY_LIST=(`cat /tmp/splunk_genesys_cloud_edge_trunks_list | grep -i \/edges\/trunks\/ | awk -F"/trunks/" '{print $2}' | sed -e 's/"//g'`)

# cat /tmp/splunk_genesys_cloud_edge_trunks_list |  grep -i \/edges\/trunks\/ | awk -F"trunks/" '{print $2}' | sed -e 's/^/\"/g'

#echo "${ENTITY_LIST[@]:0:2}" | sed -e 's/ /,/g'
#echo "${ENTITY_LIST[@]:3:2}" | sed -e 's/ /,/g'
#echo "${ENTITY_LIST[@]:3:2}" | sed -e 's/ /,/g'
#echo $ENTITY_LIST
#exit

if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
	cat /tmp/splunk_genesys_cloud_edge_trunks_list | egrep -v '^\]|^\[' | sed -e 's/^    \"id/NEW_REC \"id/g' | tr '\n' ' ' | sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g'  -e 's/} /}/g' | sed -e 's/{NEW_REC */\n{/g' | sed -e 's/, *$//g'
	echo ""
else
	cat /tmp/splunk_genesys_cloud_edge_trunks_list
fi

################################################
#------------------> Fetch Converation Details
################################################
if [ $ENV_TIMESTAMP_LABLE = "Y" ] ; then
	echo "`date +%Y-%m-%d-%H:%M:%S` Splunk - Genesys Cloud : Conversation detail dump data timestamp : Between $TIME_START -> $TIME_END"
else
	dummy=1
fi

################################################
#------------------> Main loop 
################################################
for loop_cnt in 0 50 100 150 200 250 300 350 400 450 500

do
	ENTITY_LIST_PARTIAL=${ENTITY_LIST[@]:${loop_cnt}:50}
	ENTITY_LIST_PARTIAL="`echo $ENTITY_LIST_PARTIAL | sed -e 's/ /,/g'`"
	#echo "DEBUG #####################################################"
	#echo "DEBUG ### $ENTITY_LIST_PARTIAL ###"

if [ -n "$ENTITY_LIST_PARTIAL" ]; then

	if [ $ENV_SINGLE_JSON_LINE = "Y" ] ; then
		$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc telephony providers edges trunks metrics list --trunkIds $ENTITY_LIST_PARTIAL | egrep -v '^\]|^\[' | sed -e 's/^    \"eventTime/NEW_REC \"eventTime/g' | tr '\n' ' ' | sed -e 's/  */ /g' -e 's/{ /{/g' -e 's/ }/}/g' -e 's/\[ /\[/g' -e 's/} /}/g'  -e 's/} /}/g' | sed -e 's/{NEW_REC */\n{/g' | sed -e 's/, *$//g'
		echo ""
	else
		$SCRIPT_HOME/etc/apps/TA_genesys_cloud/bin/gc telephony providers edges trunks metrics list --trunkIds $ENTITY_LIST_PARTIAL
	fi

else
	dummy=1
fi

done
