#!/bin/bash

SPLUNK_HOME=`ps -fe | grep -i splunkd | grep kvstore | awk '{print $8}' | sed -e 's/\/bin\/splunkd//g'`
SCRIPT_HOME="$SPLUNK_HOME/etc/apps/TA_genesys_cloud/bin"

cd $SCRIPT_HOME
#tar xvfz genesys_cloud_cli.tar.gz

clear

echo "

==========================================================================
	Detected Splunk Environment
==========================================================================

Detected your \$SPLUNK_HOME : $SPLUNK_HOME
Script home is : $SCRIPT_HOME

==========================================================================
	Instruction on install prompt
==========================================================================
Profile Name [DEFAULT]:   <--- Can just enter to leave as \"DEFAULT\"
Environment [mypurecloud.com]: YOUR_REGION_HERE  <--- Like (mypurecloud.com, usw2.pure.cloud, cac1.pure.cloud, mypurecloud.de, mypurecloud.ie, euw2.pure.cloud, aps1.pure.cloud, apne2.pure.cloud, mypurecloud.com.au, mypurecloud.jp) -  (* Must Enter)
Access Token:  <--- Can just enter to leave as blank
Client ID:  YOUR_CLIENT_ID   <--- Oauth Client ID created in Genesys Cloud instance (* Must Enter)
Client Secret:  YOUR_CLIENT_SECRET   <--- Oauth Secret (* Must Enter)
==========================================================================

"

echo "alias gc='$SCRIPT_HOME/gc'" >> ~/.bashrc
. ~/.bashrc
$SCRIPT_HOME/gc profiles new

echo "

PROFILE CREATED..

To Test Intergration :  gc routing queues list --autopaginate"

echo "

==========================================================================
        Testing - Connection results - will show you routing queues as test
==========================================================================
"

chmod 755 $SCRIPT_HOME/gc $SCRIPT_HOME/gc_get_*
$SCRIPT_HOME/gc routing queues list --autopaginate | grep -i "^    \"id"

echo "


==========================================================================
        Install and configuration complete 
==========================================================================

"

