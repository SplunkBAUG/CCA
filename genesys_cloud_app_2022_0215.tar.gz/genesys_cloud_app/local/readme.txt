This is where you put all your configs for this app. Splunk Web will write out configs here, too.
