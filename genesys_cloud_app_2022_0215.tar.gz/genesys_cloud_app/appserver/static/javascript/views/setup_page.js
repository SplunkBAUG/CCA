"use strict";

import * as Splunk from './splunk_helpers.js'
import * as Config from './setup_configuration.js'

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

const MACROS_CONF = 'macros'

export async function perform(splunk_js_sdk, setup_options) {
    var app_name = "genesys_cloud_app";

    var application_name_space = {
        owner: "nobody",
        app: app_name,
        sharing: "app",
    };

    try {
        // Create the Splunk JS SDK Service object

        const splunk_js_sdk_service = Config.create_splunk_js_sdk_service(
            splunk_js_sdk,
            application_name_space,
        );

        let { ...inputs } = setup_options;

        var properties = {'definition':inputs.genesys_cloud_index}

        // Get macros.conf and do stuff to it
        await Splunk.update_configuration_file(
            splunk_js_sdk_service,
            MACROS_CONF,
            'genesys_cloud_index',
            properties
        )

        var properties = {'definition':inputs.genesys_cloud_correlation_index}

        await Splunk.update_configuration_file(
            splunk_js_sdk_service,
            MACROS_CONF,
            'genesys_cloud_correlation_index',
            properties
        )

        // Completes the setup, by access the app.conf's [install]
        // stanza and then setting the `is_configured` to true
        await Config.complete_setup(splunk_js_sdk_service);

        // Reloads the splunk app so that splunk is aware of the
        // updates made to the file system
        await Config.reload_splunk_app(splunk_js_sdk_service, app_name);

        // adding one second wait time to due to Spunk JS promise timing issues on some os/environments combinations
        await sleep(1000);

        // Redirect to the Splunk App's home page
        Config.redirect_to_splunk_app_homepage(app_name);
    } catch (error) {
        // This could be better error catching.
        // Usually, error output that is ONLY relevant to the user
        // should be displayed. This will return output that the
        // user does not understand, causing them to be confused.
        console.log('Error:' + error);
    }
}
